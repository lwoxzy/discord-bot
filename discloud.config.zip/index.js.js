const { 
    Client, 
    GatewayIntentBits, 
    PermissionFlagsBits, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ChannelType 
} = require('discord.js');

const { joinVoiceChannel, VoiceConnectionStatus } = require('@discordjs/voice');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates
    ]
});

// --- AYARLAR ---
const PREFIX = '.'; 
const TOKEN = 'MTU1Mzc4Nzk0NDI2MTc4Nzc1OA.GuRiUV.IYOoMG0D7d7agcbOM1_c6DYC3zihP1iGa8E6g4'; 
const SES_KANAL_ID = '1553829597756268595'; 
const SOHBET_KANAL_ID = '1487942407214596266'; 

// --- GERÇEK KURAN-I KERİM AYETLERİ ARŞİVİ ---
const ayetler = [
    { meal: "Şüphesiz ALLAH, adaletli olmayı, iyilik yapmayı ve akrabaya yardım etmeyi emreder.", sure: "Nahl Suresi", no: 90 },
    { meal: "ALLAH, hiç kimseye gücünün yettiğinden fazlasını yüklemez.", sure: "Bakara Suresi", no: 286 },
    { meal: "Bilesiniz ki, kalpler ancak ALLAH'ı anmakla huzur bulur.", sure: "Ra'd Suresi", no: 28 },
    { meal: "ALLAH sabredenlerle beraberdir.", sure: "Bakara Suresi", no: 153 },
    { meal: "Sizin ilahınız tek bir ilahtır. O'ndan başka ilah yoktur. O, Rahmân'dır, Rahîm'dir.", sure: "Bakara Suresi", no: 163 },
    { meal: "De ki: O ALLAH'tır, tektir. ALLAH Samed'dir. O, doğurmamış ve doğmamıştır.", sure: "İhlâs Suresi", no: "1-3" },
    { meal: "ALLAH size yardım ederse, artık sizi yenecek hiç kimse yoktur.", sure: "Âl-i İmrân Suresi", no: 160 },
    { meal: "Şüphesiz ki ALLAH çok bağışlayandır, çok merhamet edendir.", sure: "Nisa Suresi", no: 23 },
    { meal: "ALLAH, müminlerin dostudur; onları karanlıklardan aydınlığa çıkarır.", sure: "Bakara Suresi", no: 257 },
    { meal: "Şüphesiz benim namazım, ibadetlerim, yaşamım ve ölümüm âlemlerin Rabbi olan ALLAH içindir.", sure: "En'âm Suresi", no: 162 },
    { meal: "O, girmesini sağlayacağın yere dürüstlükle girmemi sağlasın, çıkacağını dürüstçe çıkarmayı sağlasın. Katından bana yardım edici bir güç ver.", sure: "İsrâ Suresi", no: 80 },
    { meal: "ALLAH bize yeter, O ne güzel vekildir.", sure: "Âl-i İmrân Suresi", no: 173 },
    { meal: "Kim ALLAH'a tevekkül ederse, ALLAH ona yeter.", sure: "Talâk Suresi", no: 3 },
    { meal: "ALLAH'ın rahmetinden ümidinizi kesmeyin. Şüphesiz ALLAH bütün günahları bağışlar.", sure: "Zümer Suresi", no: 53 }
];

// --- ZİKİR ARŞİVİ ---
const zikirler = [
    "📿 SübhanALLAH (ALLAH her türlü noksanlıktan münezzehtir)",
    "📿 Elhamdülillâhi Rabbil 'Âlemîn (Hamd, âlemlerin Rabbi olan ALLAH'a mahsustur)",
    "📿 ALLAHu Akbar (ALLAH en büyüktür)",
    "📿 Lâ ilâhe illALLAH (ALLAH'tan başka ilah yoktur)",
    "📿 AstagfirULLAH el-Azîm (Yüce ALLAH'tan bağışlanma dilerim)",
    "📿 Lâ havle ve lâ kuvvete illâ billâhil 'Aliyyil 'Azîm (Güç ve kuvvet ancak Yüce ALLAH'ın yardımıyladır)",
    "📿 SübhanALLAHİ ve bihamdihi, SübhanALLAHil 'Azîm (ALLAH'ı hamd ile tesbih ederim, Yüce ALLAH noksanlıklardan münezzehtir)",
    "📿 HasbunALLAHU ve ni'mel vekîl (ALLAH bize yeter, O ne güzel vekildir)",
    "📿 Lâ ilâhe illâ ente subhâneke innî kuntu minez-zâlimîn (Senden başka ilah yoktur, seni tenzih ederim. Ben zalimlerden oldum)",
    "📿 ALLAHümme salli 'alâ seyyidinâ Muhammedin ve 'alâ âli seyyidinâ Muhammed"
];

// --- GENİŞ FIKRA HAVUZU ---
const tumFikralar = {
    komik: [
        "Adamın biri yolda yürürken yerde bir ayna bulmuş. Eğilip aynaya bakmış ve 'Cebimden düşmüş sanmıştım, meğer ne kadar çirkin bir adammış!' deyip aynayı yere atmış.",
        "Nasreddin Hoca'ya sormuşlar: 'Hoca efendi, ay yeni doğunca eskisini ne yaparlar?' Hoca tebessüm etmiş: 'Kırpıp kırpıp yıldız yaparlar!'",
        "İki arkadaş çölde yürüyormuş. Biri diğerine 'Ayağım acıyor' demiş. Diğeri 'Ayakkabını çıkar' deyince, 'Çıkaramam, içinde kum var, ayakkabımı çıkarırsam kum dökülür' yanıtını vermiş.",
        "Müşteri berbere sormuş: 'Usta, saçım çok dökülüyor ne yapayım?' Berber rahat bir tavırla: 'Bir poşete koy, sakla evladım!' demiş.",
        "Temel bir gün uçağa binmiş. Yanındaki adama 'Uçak düşerse ne yaparız?' demiş. Adam 'Paraşüt açarız' yanıtını verince Temel 'Peki paraşüt açılmazsa?' demiş. Adam 'Yere kadar yolumuz var Temel' demiş!"
    ],
    korku: [
        "Gece vakti mezarlık kestirmesinden geçen adam, arkasından gelen ayak seslerini duyunca koşmaya başlamış. Arkadaki adam da koşmuş. Öndeki dayanamayıp durmuş: 'Ne istiyorsun benden?' Adam nefes nefese cevap vermiş: 'Yahu tek başıma korkuyordum, seninle yürüyeyim dedim!'",
        "Gece yarısı adamın biri fırtınalı havada otostop çekmiş. Duran arabanın şoför koltuğunda kimsenin olmadığını, arabanın kendi kendine gittiğini görünce dehşetle arabaya binmiş. Bir süre sonra araba viraja yaklaşınca pencereden bir el girip direksiyonu çevirmiş. Adam çığlık atıp arabadan kaçmış. Meğer araba bozulmuş, arkadaki adamlar arabayı itiyormuş!",
        "Adam gece yarısı terk edilmiş binada yürürken arkadan bir ses duyulmuş: 'Bana bakarsan pişman olursun!' Adam korkarak dönmüş... Meğer bozuk bir ses kayıt cihazı yerde çalıyormuş."
    ],
    okul: [
        "Öğretmen Ali'ye sormuş: 'Oğlum 10 elman var, 3'ünü bana verirsen ne kalır?' Ali cevap vermiş: 'Öğretmenim sizde 3 elma, bende 7 elma kalır!'",
        "Öğretmen sınıfa sorar: 'Çocuklar söyleyin bakalım, yerçekimi olmasaydı ne olurdu?' Öğrenci cevap verir: 'Teneffüste düşüp dizimizi kanatmazdık hocam!'",
        "Öğretmen: 'Evladım, sınavda arkana bakma!' Öğrenci: 'Hocam arkamda gelecek var, bakmazsam nasıl görürüm?'"
    ],
    asker: [
        "Komutan erlere sormuş: 'Savaşta tüfeğiniz bozulursa ne yaparsınız?' Er: 'Süngü takarım komutanım!' Komutan: 'Süngü kırılırsa?' Er: 'Taş atarım!' Komutan: 'Taş biterse?' Er: 'Ula komutanım sen de benden yanamısın düşmandan yana mı?!'",
        "Nöbetçi er gece karanlığında yaklaşan karartıya bağırmış: 'Dur! Parola ne?' Karartıdan ses gelmiş: 'Evlat benim, komutanın!' Er cevap vermiş: 'Yanlış parola komutanım, parolanın doğrusu Şafak olacaktı!'"
    ]
};

// --- HİÇBİR ŞEYİN TEKRAR ETMEMESİ İÇİN BELLEK (SET) SİSTEMİ ---
const anlatilanFikralar = new Set();
const okunanAyetler = new Set();
const çekilenZikirler = new Set();

function rastgeleFikraGetir(tur) {
    let secilecekKategori = (tur && tumFikralar[tur]) ? tumFikralar[tur] : Object.values(tumFikralar).flat();
    let anlatilmayanlar = secilecekKategori.filter(f => !anlatilanFikralar.has(f));

    if (anlatilmayanlar.length === 0) {
        // Tüm fıkralar anlatıldıysa belleği temizle ve baştan başla
        secilecekKategori.forEach(f => anlatilanFikralar.delete(f));
        anlatilmayanlar = secilecekKategori;
    }

    const secilen = anlatilmayanlar[Math.floor(Math.random() * anlatilmayanlar.length)];
    anlatilanFikralar.add(secilen);
    return secilen;
}

function rastgeleAyetGetir() {
    let okunmayanlar = ayetler.filter(a => !okunanAyetler.has(a.sure + a.no));
    if (okunmayanlar.length === 0) {
        // Tüm ayetler okunduysa belleği temizle ve baştan başla
        okunanAyetler.clear();
        okunmayanlar = ayetler;
    }
    const secilen = okunmayanlar[Math.floor(Math.random() * okunmayanlar.length)];
    okunanAyetler.add(secilen.sure + secilen.no);
    return secilen;
}

function rastgeleZikirGetir() {
    let cekilmeyenler = zikirler.filter(z => !çekilenZikirler.has(z));
    if (cekilmeyenler.length === 0) {
        // Tüm zikirler çekildiyse sıfırla
        çekilenZikirler.clear();
        cekilmeyenler = zikirler;
    }
    const secilen = cekilmeyenler[Math.floor(Math.random() * cekilmeyenler.length)];
    çekilenZikirler.add(secilen);
    return secilen;
}

// --- YARDIMCI FONKSİYONLAR ---
async function findGuildMember(guild, input) {
    if (!input) return null;
    let member = guild.members.cache.get(input.replace(/[<@!>]/g, ''));
    if (!member) {
        try {
            const fetched = await guild.members.fetch(input.replace(/[<@!>]/g, ''));
            if (fetched) member = fetched;
        } catch (e) {
            member = guild.members.cache.find(m => 
                m.user.username.toLowerCase() === input.toLowerCase() || 
                m.displayName.toLowerCase() === input.toLowerCase()
            );
        }
    }
    return member;
}

async function getOrCreateLogChannel(guild) {
    let logChannel = guild.channels.cache.find(c => c.name === 'bot-log' && c.type === ChannelType.GuildText);
    if (!logChannel) {
        try {
            logChannel = await guild.channels.create({
                name: 'bot-log',
                type: ChannelType.GuildText,
                topic: 'Bot otomatik işlem kayıt kanalı.',
                permissionOverwrites: [
                    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
                    { id: guild.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
                ],
            });
        } catch (err) {
            console.error('Log kanalı oluşturulamadı:', err);
        }
    }
    return logChannel;
}

function connectToVoiceChannel() {
    const channel = client.channels.cache.get(SES_KANAL_ID);
    if (!channel || channel.type !== ChannelType.GuildVoice) {
        return console.log('⚠️ Belirtilen ses kanalı ID geçersiz veya bulunamadı.');
    }

    const connection = joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        selfDeaf: true,
        selfMute: false
    });

    connection.on(VoiceConnectionStatus.Disconnected, () => {
        console.log('🔄 Sesten düşüldü, tekrar bağlanılıyor...');
        setTimeout(connectToVoiceChannel, 5000);
    });

    console.log(`🎙️ Bot başarıyla "${channel.name}" ses kanalına bağlandı.`);
}

client.once('ready', () => {
    console.log(`🚀 ${client.user.tag} başarıyla aktif edildi!`);
    client.user.setActivity(`${PREFIX}yardım | Özel Sunucu Botu`, { type: 0 });
    connectToVoiceChannel();
});

// 1. OTOMATİK KARŞILAMA (TAG ATMADAN SOHBET KANALINA)
client.on('guildMemberAdd', async (member) => {
    const chatChannel = member.guild.channels.cache.get(SOHBET_KANAL_ID);
    if (chatChannel) {
        chatChannel.send(`${member.user.username} sunucumuza hoş geldiniz lütfen düzgün davranışlar sergileyelim`);
    }

    const logChannel = await getOrCreateLogChannel(member.guild);
    if (logChannel) {
        const embed = new EmbedBuilder()
            .setTitle('📥 Yeni Üye Katıldı')
            .setColor(0x2ECC71)
            .setDescription(`${member.user.username} (${member.user.tag} - ID: ${member.id}) sunucuya katıldı.`)
            .setTimestamp();
        logChannel.send({ embeds: [embed] });
    }
});

// ANA MESAJ DİNLENMESİ
client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;

    // 2. TAGSIZ / NOKTASIZ OTOMATİK SELAM CEVABI (Tüm Kanallarda)
    const icerik = message.content.toLowerCase().trim();
    const selamKelimeleri = ['sa', 'selamün aleyküm', 'selamun aleykum', 'selamun aleyküm', 'sea', 'selam'];
    if (selamKelimeleri.includes(icerik)) {
        return message.channel.send('aleyküm selam hoş geldin');
    }

    // 3. ÖZEL ROL VERME / ALMA ("user/ID pro rolver" VEYA "user/ID pro rolal")
    if (icerik.includes('rolver') || icerik.includes('rolal')) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply('❌ Rolleri yönetme yetkiniz bulunmuyor!');
        }

        const isVer = icerik.includes('rolver');
        const cleanContent = message.content.replace('.rolver', '').replace('rolver', '').replace('.rolal', '').replace('rolal', '').trim();
        const argsRol = cleanContent.split(/ +/);

        const targetMember = await findGuildMember(message.guild, argsRol[0]);
        if (!targetMember) return message.reply('❌ Kullanıcı etiket, kullanıcı adı veya ID ile bulunamadı!');

        const roleSearch = argsRol.slice(1).join(' ').trim();
        const targetRole = message.guild.roles.cache.find(r => r.name.toLowerCase() === roleSearch.toLowerCase() || r.id === roleSearch);

        if (!targetRole) return message.reply(`❌ **"${roleSearch}"** adında veya ID'sinde bir rol bulunamadı!`);

        if (isVer) {
            await targetMember.roles.add(targetRole);
            return message.channel.send(`✅ **${targetMember.user.tag}** kullanıcısına **${targetRole.name}** rolü verildi.`);
        } else {
            await targetMember.roles.remove(targetRole);
            return message.channel.send(`🗑️ **${targetMember.user.tag}** kullanıcısından **${targetRole.name}** rolü alındı.`);
        }
    }

    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // YARDIM MENÜSÜ
    if (command === 'yardım' || command === 'help') {
        const embed = new EmbedBuilder()
            .setTitle('📜 Bot Komut Menüsü')
            .setColor(0x3498DB)
            .addFields(
                { name: '🛡️ Moderasyon', value: '`.ban [User/ID]`, `.kick [User/ID]`, `.mute [User/ID] [Dk]`, `.sil [Sayı]`, `.çek [User/ID]`, `[User/ID] [Rol] rolver`, `[User/ID] [Rol] rolal`' },
                { name: '📬 İletişim', value: '`.dmmesaj @User/ID/everyone [mesaj]`' },
                { name: '🕌 Dini Komutlar', value: '`.namaz [şehir]`, `.ayet`, `.zikir`' },
                { name: '🎉 Eğlence', value: '`.fıkra [tür]` (komik, korku, okul, asker), `.zar`, `.yazıtura`, `.8ball`, `.avatar`, `.kullanıcı`, `.sunucu`' }
            );
        return message.channel.send({ embeds: [embed] });
    }

    // 4. TEKRARSIZ AYET KOMUTU (.ayet)
    else if (command === 'ayet') {
        const ayet = rastgeleAyetGetir();
        const embed = new EmbedBuilder()
            .setTitle('📖 Kuran-ı Kerim Meal')
            .setDescription(`"${ayet.meal}"`)
            .setColor(0x27AE60)
            .setFooter({ text: `📌 ${ayet.sure}, ${ayet.no}. Ayet` });
        return message.channel.send({ embeds: [embed] });
    }

    // 5. TEKRARSIZ ZİKİR KOMUTU (.zikir)
    else if (command === 'zikir') {
        const zikir = rastgeleZikirGetir();
        return message.channel.send(zikir);
    }

    // 6. TEKRARSIZ VE KATEGORİLİ FIKRA ANLATMA (.fıkra)
    else if (command === 'fıkra' || command === 'fikra') {
        const tur = args[0] ? args[0].toLowerCase() : null;
        const secilenFikra = rastgeleFikraGetir(tur);

        const embed = new EmbedBuilder()
            .setTitle(`📖 Fıkra (${tur ? tur.toUpperCase() : 'RASTGELE'})`)
            .setDescription(secilenFikra)
            .setColor(0xF1C40F)
            .setFooter({ text: 'Kategoriler: komik, korku, okul, asker' });

        return message.channel.send({ embeds: [embed] });
    }

    // 7. GÜNCEL NAMAZ VAKİTLERİ (.namaz istanbul)
    else if (command === 'namaz') {
        const sehir = args[0] || 'istanbul';
        
        try {
            const response = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(sehir)}&country=Turkey&method=13`);
            const data = await response.json();

            if (data.code !== 200 || !data.data) {
                return message.reply('❌ Şehir bulunamadı! Lütfen geçerli bir şehir adı giriniz.');
            }

            const timings = data.data.timings;
            const dateStr = data.data.date.readable;

            const embed = new EmbedBuilder()
                .setTitle(`🕌 ${sehir.toUpperCase()} - Güncel Ezan / Namaz Vakitleri`)
                .setColor(0x1ABC9C)
                .setDescription(`📅 **Tarih:** ${dateStr}`)
                .addFields(
                    { name: '🌅 İmsak', value: timings.Fajr, inline: true },
                    { name: '☀️ Güneş', value: timings.Sunrise, inline: true },
                    { name: '🏙️ Öğle', value: timings.Dhuhr, inline: true },
                    { name: '🌆 İkindi', value: timings.Asr, inline: true },
                    { name: '🌇 Akşam', value: timings.Maghrib, inline: true },
                    { name: '🌃 Yatsı', value: timings.Isha, inline: true }
                )
                .setFooter({ text: 'Vakitler Diyanet İşleri Başkanlığı metoduna uygundur.' })
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Namaz vakitleri çekilemedi:', error);
            return message.reply('❌ Namaz vakitleri alınırken bir hata oluştu.');
        }
    }

    // 8. BUTONLU BAN KOMUTU (.ban @User/ID)
    else if (command === 'ban') {
        if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return message.reply('❌ Üyeleri banlama yetkiniz yok!');
        }

        const input = args[0];
        if (!input) return message.reply('❌ Banlanacak kişiyi etiketleyin veya ID girin!');

        let targetId = input.replace(/[<@!>]/g, '');
        let targetUser;

        try {
            targetUser = await client.users.fetch(targetId);
        } catch (e) {
            return message.reply('❌ Kullanıcı Discord üzerinde bulunamadı!');
        }

        const member = message.guild.members.cache.get(targetUser.id);
        if (member && !member.bannable) return message.reply('❌ Bu kullanıcıyı banlama yetkim yetmiyor.');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ban_sil').setLabel('Banla (Mesajları Sil)').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('ban_silme').setLabel('Mesajları Silmeden Banla').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('ban_iptal').setLabel('Banlama (İptal)').setStyle(ButtonStyle.Success)
        );

        const confirmMsg = await message.channel.send({
            content: `❓ **${targetUser.tag}** (${targetUser.id}) kullanıcısına ne işlem yapmak istersiniz?`,
            components: [row]
        });

        const filter = i => i.user.id === message.author.id;
        const collector = confirmMsg.createMessageComponentCollector({ filter, time: 30000 });

        collector.on('collect', async i => {
            if (i.customId === 'ban_sil') {
                await message.guild.members.ban(targetUser.id, { deleteMessageSeconds: 604800, reason: 'Butonlu Ban' });
                await i.update({ content: `🔨 **${targetUser.tag}** mesajları silinerek banlandı!`, components: [] });
            } else if (i.customId === 'ban_silme') {
                await message.guild.members.ban(targetUser.id, { deleteMessageSeconds: 0, reason: 'Butonlu Ban' });
                await i.update({ content: `🔨 **${targetUser.tag}** mesajları silinmeden banlandı!`, components: [] });
            } else {
                await i.update({ content: '❌ Ban işlemi iptal edildi.', components: [] });
                return;
            }

            const logChannel = await getOrCreateLogChannel(message.guild);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🚫 Üye Banlandı')
                    .setColor(0xFF0000)
                    .addFields(
                        { name: 'Kullanıcı', value: `${targetUser.tag} (${targetUser.id})` },
                        { name: 'Yetkili', value: `${message.author.tag}` }
                    )
                    .setTimestamp();
                logChannel.send({ embeds: [logEmbed] });
            }
        });
    }

    // 9. KICK / ATMA KOMUTU (.kick @User/ID)
    else if (command === 'kick') {
        if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return message.reply('❌ Üyeleri sunucudan atma yetkiniz yok!');
        }

        const input = args[0];
        if (!input) return message.reply('❌ Sunucudan atılacak kişiyi etiketleyin veya ID girin!');

        const member = await findGuildMember(message.guild, input);
        if (!member) return message.reply('❌ Sunucuda böyle bir kullanıcı bulunamadı.');
        if (!member.kickable) return message.reply('❌ Bu kullanıcıyı atma yetkim yetmiyor.');

        const reason = args.slice(1).join(' ') || 'Sebep belirtilmedi';
        await member.kick(reason);
        message.channel.send(`🚪 **${member.user.tag}** sunucudan atıldı.`);

        const logChannel = await getOrCreateLogChannel(message.guild);
        if (logChannel) {
            const embed = new EmbedBuilder()
                .setTitle('🚪 Üye Sunucudan Atıldı (Kick)')
                .setColor(0xE67E22)
                .addFields(
                    { name: 'Atılan', value: `${member.user.tag} (${member.id})` },
                    { name: 'Yetkili', value: `${message.author.tag}` },
                    { name: 'Sebep', value: reason }
                )
                .setTimestamp();
            logChannel.send({ embeds: [embed] });
        }
    }

    // 10. MUTE / SUSTURMA (.mute @User/ID <Dakika>)
    else if (command === 'mute') {
        if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return message.reply('❌ Mute atmak için yetkin yetersiz!');
        }

        const input = args[0];
        const duration = parseInt(args[1]);

        if (!input || isNaN(duration)) {
            return message.reply('❌ Kullanım: `.mute @kullanıcı/ID <dakika>`');
        }

        const member = await findGuildMember(message.guild, input);
        if (!member) return message.reply('❌ Sunucuda böyle bir kullanıcı bulunamadı.');

        await member.timeout(duration * 60 * 1000, 'Mute Komutu');
        message.channel.send(`🤐 **${member.user.tag}**, ${duration} dakika boyunca susturuldu.`);

        const logChannel = await getOrCreateLogChannel(message.guild);
        if (logChannel) {
            const embed = new EmbedBuilder()
                .setTitle('🤐 Üye Mute Yedi')
                .setColor(0x9B59B6)
                .addFields(
                    { name: 'Susturulan', value: `${member.user.tag} (${member.id})` },
                    { name: 'Süre', value: `${duration} Dk` },
                    { name: 'Yetkili', value: `${message.author.tag}` }
                )
                .setTimestamp();
            logChannel.send({ embeds: [embed] });
        }
    }

    // 11. SESE ÇEKME (.çek @User/ID/İsim)
    else if (command === 'çek') {
        if (!message.member.permissions.has(PermissionFlagsBits.MoveMembers)) {
            return message.reply('❌ Üyeleri taşıma yetkiniz yok!');
        }

        const voiceChannel = message.member.voice.channel;
        if (!voiceChannel) return message.reply('❌ Önce bir ses kanalında olmalısınız!');

        const input = args[0];
        if (!input) return message.reply('❌ Bir kullanıcı etiketleyin, isim yazın veya ID girin!');

        const member = await findGuildMember(message.guild, input);
        if (!member || !member.voice.channel) return message.reply('❌ Kullanıcı sunucuda veya bir ses kanalında bulunamadı!');

        await member.voice.setChannel(voiceChannel);
        message.channel.send(`🔊 **${member.user.tag}**, bulunduğunuz **${voiceChannel.name}** kanalına çekildi.`);
    }

    // 12. DM MESAJ GÖNDERME (.dmmesaj @User/ID/everyone mesaj)
    else if (command === 'dmmesaj') {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply('❌ DM göndermek için **Yönetici** olmalısınız!');
        }

        const targetArg = args[0];
        const dmMsg = args.slice(1).join(' ');

        if (!targetArg || !dmMsg) return message.reply('❌ Kullanım: `.dmmesaj @kullanıcı/ID/everyone [mesaj]`');

        if (targetArg.toLowerCase() === 'everyone') {
            const members = await message.guild.members.fetch();
            let count = 0;
            members.forEach(m => {
                if (!m.user.bot) {
                    m.send(`📢 **${message.guild.name}** Sunucusundan Duyuru:\n${dmMsg}`).catch(() => {});
                    count++;
                }
            });
            message.channel.send(`📬 Toplam **${count}** kullanıcıya DM gönderilmeye başlandı.`);
        } else {
            let targetUser;
            const cleanId = targetArg.replace(/[<@!>]/g, '');

            try {
                targetUser = await client.users.fetch(cleanId);
            } catch (e) {
                targetUser = null;
            }

            if (!targetUser) return message.reply('❌ Geçerli bir kullanıcı etiketleyin veya ID girin!');
            
            try {
                await targetUser.send(`📩 **${message.guild.name}** sunucusundan mesajınız var:\n${dmMsg}`);
                message.channel.send(`✅ **${targetUser.tag}** kullanıcısına DM başarıyla gönderildi.`);
            } catch (err) {
                message.reply('❌ Kullanıcının DM kutusu kapalı olduğu için mesaj gönderilemedi.');
            }
        }
    }

    // 13. MESAJ SİLME KOMUTU (.sil veya .sil 50)
    else if (command === 'sil') {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return message.reply('❌ Mesajları silme yetkiniz yok!');
        }

        let miktar = parseInt(args[0]) || 100;
        if (miktar > 100) miktar = 100;

        await message.channel.bulkDelete(miktar, true);
        message.channel.send(`🗑️ **${miktar}** adet mesaj silindi.`).then(m => setTimeout(() => m.delete(), 3000));
    }

    // 14. EĞLENCE KOMUTLARI
    else if (command === 'zar') {
        message.reply(`🎲 Attığın zar: **${Math.floor(Math.random() * 6) + 1}**`);
    }
    else if (command === 'yazıtura') {
        message.reply(`🪙 **${Math.random() < 0.5 ? 'Yazı' : 'Tura'}** geldi!`);
    }
    else if (command === '8ball') {
        const cevaplar = ['Evet kesinlikle!', 'Şüphesiz.', 'Daha sonra tekrar sor.', 'Pek sanmıyorum.', 'Hayır!'];
        const soru = args.join(' ');
        if (!soru) return message.reply('Bir soru sormalısın!');
        message.reply(`🔮 **Soru:** ${soru}\n**Cevap:** ${cevaplar[Math.floor(Math.random() * cevaplar.length)]}`);
    }
    else if (command === 'avatar') {
        const targetMember = await findGuildMember(message.guild, args[0]) || message.member;
        const embed = new EmbedBuilder()
            .setTitle(`${targetMember.user.username} Profil Resmi`)
            .setImage(targetMember.user.displayAvatarURL({ size: 1024, dynamic: true }))
            .setColor(0x3498DB);
        message.channel.send({ embeds: [embed] });
    }
    else if (command === 'kullanıcı') {
        const targetMember = await findGuildMember(message.guild, args[0]) || message.member;
        const embed = new EmbedBuilder()
            .setTitle(`👤 ${targetMember.user.username} Kullanıcı Bilgisi`)
            .setThumbnail(targetMember.user.displayAvatarURL())
            .setColor(0x9B59B6)
            .addFields(
                { name: 'Kullanıcı Adı', value: targetMember.user.tag, inline: true },
                { name: 'ID', value: targetMember.id, inline: true },
                { name: 'Sunucuya Katılma', value: `<t:${Math.floor(targetMember.joinedTimestamp / 1000)}:R>`, inline: false }
            );
        message.channel.send({ embeds: [embed] });
    }
    else if (command === 'sunucu') {
        const embed = new EmbedBuilder()
            .setTitle(`🏰 ${message.guild.name} Sunucu Bilgisi`)
            .setThumbnail(message.guild.iconURL())
            .setColor(0x2ECC71)
            .addFields(
                { name: 'Toplam Üye', value: `${message.guild.memberCount}`, inline: true }
            );
        message.channel.send({ embeds: [embed] });
    }
});

client.login(TOKEN);